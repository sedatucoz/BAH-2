package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// Personnel Data Class with state properties
class Personel(
    val id: String,
    initialName: String,
    initialPuan: Double,
    initialActive: Boolean = true
) {
    var ad by mutableStateOf(initialName)
    var puanInput by mutableStateOf(initialPuan.toString())
    var calistiMi by mutableStateOf(initialActive)

    val puan: Double
        get() = puanInput.replace(',', '.').toDoubleOrNull() ?: 0.0
}

class KesintiKategori(
    val id: String,
    initialName: String,
    initialPercentage: Double
) {
    var adi by mutableStateOf(initialName)
    var yuzdeInput by mutableStateOf(initialPercentage.toString())

    val yuzde: Double
        get() = yuzdeInput.replace(',', '.').toDoubleOrNull() ?: 0.0
}

// Day Data Class to track Tip inputs and attendance for that specific day
class GunVeri(val adi: String) {
    var nakit by mutableStateOf("")
    var kart by mutableStateOf("")
    val calisanlar = mutableStateMapOf<String, Boolean>()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(dynamicColor = false) {
                BahsisHesaplayiciApp()
            }
        }
    }
}

// Safe mathematical rounding to handle infinity or extreme user input gracefully without crashes
fun Double.safeRoundToInt(): Int {
    if (this.isNaN() || this.isInfinite()) return 0
    if (this > Int.MAX_VALUE.toDouble()) return Int.MAX_VALUE
    if (this < Int.MIN_VALUE.toDouble()) return Int.MIN_VALUE
    return this.roundToInt()
}

// Thread-safe data transfer objects for SharedPreferences serialization
class PersonelData(val id: String, val ad: String, val puanInput: String)
class GunVeriData(val nakit: String, val kart: String, val calisanlar: Map<String, Boolean>)
class KesintiKategoriData(val id: String, val adi: String, val yuzdeInput: String)

// SharedPreferences State persistence helpers to retain results between sessions safely
fun ipucuKaydet(
    context: android.content.Context,
    personeller: List<PersonelData>,
    gunler: List<GunVeriData>,
    kesintiler: List<KesintiKategoriData>
) {
    val prefs = context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE)
    val editor = prefs.edit()
    
    // Save personnel IDs
    val idsStr = personeller.joinToString(",") { it.id }
    editor.putString("personel_ids", idsStr)
    
    personeller.forEach { p ->
        editor.putString("name_${p.id}", p.ad)
        editor.putString("puan_${p.id}", p.puanInput)
    }
    
    // Save each day's values
    gunler.forEachIndexed { idx, v ->
        editor.putString("day_nakit_$idx", v.nakit)
        editor.putString("day_kart_$idx", v.kart)
        // Store attendance mappings by ID
        personeller.forEach { p ->
            editor.putBoolean("day_active_${idx}_${p.id}", v.calisanlar[p.id] ?: true)
        }
    }

    // Save deduction categories
    val kesintiIds = kesintiler.joinToString(",") { it.id }
    editor.putString("kesinti_ids", kesintiIds)
    kesintiler.forEach { k ->
        editor.putString("kesinti_name_${k.id}", k.adi)
        editor.putString("kesinti_yuzde_${k.id}", k.yuzdeInput)
    }

    editor.apply()
}

fun ipucuYukle(
    context: android.content.Context,
    personeller: SnapshotStateList<Personel>,
    gunler: List<GunVeri>,
    kesintiler: SnapshotStateList<KesintiKategori>
) {
    val prefs = context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE)
    try {
        val idsStr = prefs.getString("personel_ids", null)
        
        personeller.clear()
        if (idsStr != null) {
            val ids = idsStr.split(",").filter { it.isNotBlank() }
            ids.forEach { id ->
                val name = prefs.getString("name_$id", "") ?: ""
                val points = prefs.getString("puan_$id", "1.00") ?: "1.00"
                personeller.add(Personel(id, name, points.replace(',', '.').toDoubleOrNull() ?: 1.0).apply {
                    puanInput = points
                })
            }
        } else {
            val oldNamesStr = prefs.getString("personel_names", null)
            if (oldNamesStr != null) {
                val names = oldNamesStr.split(",").filter { it.isNotBlank() }
                names.forEach { name ->
                    val points = prefs.getString("puan_$name", "1.00") ?: "1.00"
                    personeller.add(Personel(name, name, points.replace(',', '.').toDoubleOrNull() ?: 1.0).apply {
                        puanInput = points
                    })
                }
            } else {
                // Fallback to the standard starting roster specified by user
                personeller.addAll(
                    listOf(
                        Personel("cem_id", "Cem", 1.22),
                        Personel("sedat_id", "Sedat", 1.0),
                        Personel("hasan_id", "Hasan", 1.0),
                        Personel("onur_id", "Onur", 0.44),
                        Personel("nergiz_id", "Nergiz", 1.0),
                        Personel("izzettin_id", "İzzettin", 1.0)
                    )
                )
            }
        }
        
        gunler.forEachIndexed { idx, v ->
            v.nakit = prefs.getString("day_nakit_$idx", "") ?: ""
            v.kart = prefs.getString("day_kart_$idx", "") ?: ""
            personeller.forEach { p ->
                val newKey = "day_active_${idx}_${p.id}"
                if (prefs.contains(newKey)) {
                    v.calisanlar[p.id] = prefs.getBoolean(newKey, true)
                } else {
                    v.calisanlar[p.id] = prefs.getBoolean("day_active_${idx}_${p.ad}", true)
                }
            }
        }

        // Load deduction categories
        val kesintiIdsStr = prefs.getString("kesinti_ids", null)
        kesintiler.clear()
        if (kesintiIdsStr != null) {
            val ids = kesintiIdsStr.split(",").filter { it.isNotBlank() }
            ids.forEach { id ->
                val name = prefs.getString("kesinti_name_$id", "") ?: ""
                val yuzde = prefs.getString("kesinti_yuzde_$id", "0.0") ?: "0.0"
                kesintiler.add(KesintiKategori(id, name, yuzde.replace(',', '.').toDoubleOrNull() ?: 0.0).apply {
                    yuzdeInput = yuzde
                })
            }
        } else {
            // Defaults
            kesintiler.addAll(
                listOf(
                    KesintiKategori("mutfak_id", "Mutfak", 15.0),
                    KesintiKategori("taskapi_id", "Taşkapı", 5.0)
                )
            )
        }

    } catch (e: Exception) {
        android.util.Log.e("BahsisApp", "Failed to load preferences, using fallback roster", e)
        personeller.clear()
        personeller.addAll(
            listOf(
                Personel("cem_id", "Cem", 1.22),
                Personel("sedat_id", "Sedat", 1.0),
                Personel("hasan_id", "Hasan", 1.0),
                Personel("onur_id", "Onur", 0.44),
                Personel("nergiz_id", "Nergiz", 1.0),
                Personel("izzettin_id", "İzzettin", 1.0)
            )
        )
        gunler.forEach { v ->
            v.nakit = ""
            v.kart = ""
            v.calisanlar.clear()
            personeller.forEach { p ->
                v.calisanlar[p.id] = true
            }
        }
        kesintiler.clear()
        kesintiler.addAll(
            listOf(
                KesintiKategori("mutfak_id", "Mutfak", 15.0),
                KesintiKategori("taskapi_id", "Taşkapı", 5.0)
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BahsisHesaplayiciApp() {
    val context = LocalContext.current
    var showDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var saveTrigger by remember { mutableStateOf(0) }

    // Colors aligned with the "Frosted Glass" design theme spec
    val primaryGreen = Color(0xFF386B01)
    val textPrimary = Color(0xFF1A1C19)
    val textSecondary = Color(0xFF43493E)
    val bgGreenLight = Color(0xFFF7FBF2)
    val glassBg = Color(0xFFE1E9D7).copy(alpha = 0.6f)
    val borderLight = Color(0xFFE1E9D7)
    val borderMuted = Color(0xFFC1C9B7)
    val inputBorderColor = Color(0xFF74796D)

    // Initial List of personnel (will be loaded on launch)
    val personeller = remember { mutableStateListOf<Personel>() }
    val kesintiler = remember { mutableStateListOf<KesintiKategori>() }

    // Standard days of the week list
    val gunlerList = remember {
        listOf("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")
    }

    // Days representation data structures
    val gunVerileri = remember {
        mutableStateListOf<GunVeri>().apply {
            if (isEmpty()) {
                gunlerList.forEach { name ->
                    add(GunVeri(name))
                }
            }
        }
    }

    // Load persisted state on mount
    var hasLoaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        ipucuYukle(context, personeller, gunVerileri, kesintiler)
        hasLoaded = true
    }

    // Capture changes to saveTrigger without causing recomposition of BahsisHesaplayiciApp
    val hasUnsavedEdits = remember { java.util.concurrent.atomic.AtomicBoolean(false) }
    LaunchedEffect(Unit) {
        snapshotFlow { saveTrigger }.collect { valTrigger ->
            if (valTrigger > 0) {
                hasUnsavedEdits.set(true)
            }
        }
    }

    // Auto-save system runs periodically on a 2-second interval, checking if edits occurred
    LaunchedEffect(hasLoaded) {
        if (hasLoaded) {
            while (true) {
                delay(2000)
                if (hasUnsavedEdits.getAndSet(false)) {
                    try {
                        val personellerCopy = personeller.toList().map { PersonelData(it.id, it.ad, it.puanInput) }
                        val gunlerCopy = gunVerileri.toList().map { g ->
                            GunVeriData(g.nakit, g.kart, g.calisanlar.toMap())
                        }
                        val kesintilerCopy = kesintiler.toList().map { KesintiKategoriData(it.id, it.adi, it.yuzdeInput) }
                        withContext(Dispatchers.IO) {
                            ipucuKaydet(context, personellerCopy, gunlerCopy, kesintilerCopy)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("BahsisApp", "Auto-save failed safely", e)
                    }
                }
            }
        }
    }

    // Selected tab: 0-6 represent weekdays, index 7 is the "Haftalık Özet" summary report
    var currentTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { 
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Bahşiş Dağıtım v3", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, letterSpacing = 0.5.sp)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = primaryGreen,
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(
                        onClick = { showResetDialog = true }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh, 
                            contentDescription = "Haftayı Sıfırla", 
                            tint = Color.White
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = primaryGreen,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (currentTab == 8) "Yeni Kesinti Ekle" else "Yeni Personel Ekle",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(bgGreenLight)
        ) {
            
            // Interactive visual Day Tab Row (Monday-Sunday + Weekly Summary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                gunlerList.forEachIndexed { index, name ->
                    val selected = currentTab == index
                    FilterChip(
                        selected = selected,
                        onClick = { currentTab = index },
                        label = { Text(name, fontSize = 13.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = primaryGreen,
                            selectedLabelColor = Color.White,
                            containerColor = Color.Transparent,
                            labelColor = textSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = borderMuted,
                            selectedBorderColor = primaryGreen,
                            borderWidth = 1.dp
                        )
                    )
                }
                
                // Haftalık Özet Tab
                val isSummarySelected = currentTab == 7
                FilterChip(
                    selected = isSummarySelected,
                    onClick = { currentTab = 7 },
                    label = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Percent, 
                                contentDescription = null, 
                                modifier = Modifier.size(14.dp),
                                tint = if (isSummarySelected) Color.White else primaryGreen
                            )
                            Text("Haftalık Özet") 
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = primaryGreen,
                        selectedLabelColor = Color.White,
                        containerColor = glassBg,
                        labelColor = primaryGreen
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSummarySelected,
                        borderColor = borderMuted,
                        selectedBorderColor = primaryGreen,
                        borderWidth = 1.dp
                    )
                )

                // Kesinti Ayarları Tab
                val isDeductionSelected = currentTab == 8
                FilterChip(
                    selected = isDeductionSelected,
                    onClick = { currentTab = 8 },
                    label = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings, 
                                contentDescription = null, 
                                modifier = Modifier.size(14.dp),
                                tint = if (isDeductionSelected) Color.White else primaryGreen
                            )
                            Text("Kesinti Ayarları") 
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = primaryGreen,
                        selectedLabelColor = Color.White,
                        containerColor = glassBg,
                        labelColor = primaryGreen
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isDeductionSelected,
                        borderColor = borderMuted,
                        selectedBorderColor = primaryGreen,
                        borderWidth = 1.dp
                    )
                )
            }

            // Main Tab Body
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (currentTab in 0..6) {
                    val gun = gunVerileri[currentTab]
                    
                    // Header title for the day
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = "${gun.adi} Bahşiş Girişi",
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Nakit ve Kart Girişleri Section Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Nakit Field
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Nakit",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = textSecondary,
                                modifier = Modifier.padding(start = 4.dp)
                            )
                            OutlinedTextField(
                                value = gun.nakit,
                                onValueChange = { input -> 
                                    gun.nakit = input
                                    saveTrigger++
                                },
                                prefix = { Text("₺", color = textPrimary.copy(alpha = 0.5f), fontWeight = FontWeight.Medium) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedTextColor = textPrimary,
                                    unfocusedTextColor = textPrimary,
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                trailingIcon = if (gun.nakit.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { 
                                            gun.nakit = ""
                                            saveTrigger++
                                        }) {
                                            Icon(Icons.Default.Close, contentDescription = "Temizle", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                } else null
                            )
                        }

                        // Kart Field (Displays 12% off Net Tutar beneath as requested)
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Kart",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = textSecondary,
                                modifier = Modifier.padding(start = 4.dp)
                            )
                            OutlinedTextField(
                                value = gun.kart,
                                onValueChange = { input -> 
                                    gun.kart = input
                                    saveTrigger++
                                },
                                prefix = { Text("₺", color = textPrimary.copy(alpha = 0.5f), fontWeight = FontWeight.Medium) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedTextColor = textPrimary,
                                    unfocusedTextColor = textPrimary,
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                trailingIcon = if (gun.kart.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { 
                                            gun.kart = ""
                                            saveTrigger++
                                        }) {
                                            Icon(Icons.Default.Close, contentDescription = "Temizle", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                } else null
                            )
                        }
                    }

                    // Display Card Net immediately below the inputs
                    val grossKart = gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0
                    val computedKartNet = grossKart * 0.88 // Deducting 12% as formula requires
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kart Net (%12 Düşülmüş):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = textSecondary
                        )
                        Text(
                            text = "${String.format("%.2f", computedKartNet)} ₺",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryGreen
                        )
                    }

                    // Calculations for active day tab
                    val dailyNakit = gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0
                    val dailyTotal = dailyNakit + computedKartNet
                    
                    val kesintilerToplam = kesintiler.sumOf { k -> (dailyTotal * (k.yuzde / 100.0)).safeRoundToInt() }
                    val dailyKalan = dailyTotal.safeRoundToInt() - kesintilerToplam

                    val activeDayStaff = personeller.filter { p -> gun.calisanlar[p.id] ?: true }
                    val dailyTotalPoints = activeDayStaff.sumOf { it.puan }

                    // Daily Summary Card - Frosted Glass effect
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        elevation = CardDefaults.cardElevation(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Günlük Dağıtım Detayı",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryGreen,
                                    letterSpacing = 0.5.sp
                                )
                                TextButton(
                                    onClick = {
                                        val newCat = KesintiKategori(
                                            id = java.util.UUID.randomUUID().toString(),
                                            initialName = "",
                                            initialPercentage = 5.0
                                        ).apply {
                                            yuzdeInput = "5.0"
                                        }
                                        kesintiler.add(newCat)
                                        saveTrigger++
                                    },
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.height(28.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = primaryGreen)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Gider Kategori Ekle", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            OzetSatir("Toplam Toplanan (Net Ciro):", "${dailyTotal.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            
                            if (kesintiler.isEmpty()) {
                                Text(
                                    text = "Tanımlı gider kategorisi bulunmuyor.",
                                    fontSize = 12.sp,
                                    color = textSecondary,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            } else {
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    kesintiler.forEach { k ->
                                        val mValue = (dailyTotal * (k.yuzde / 100.0)).safeRoundToInt()
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            // Name edit field with placeholder
                                            BasicTextField(
                                                value = k.adi,
                                                onValueChange = {
                                                    k.adi = it
                                                    saveTrigger++
                                                },
                                                textStyle = TextStyle(
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = textPrimary
                                                ),
                                                decorationBox = { innerTextField ->
                                                    Box(contentAlignment = Alignment.CenterStart) {
                                                        if (k.adi.isEmpty()) {
                                                            Text(
                                                                text = "Kategori ismi...",
                                                                color = Color.Gray.copy(alpha = 0.4f),
                                                                fontSize = 11.sp
                                                            )
                                                        }
                                                        innerTextField()
                                                    }
                                                },
                                                modifier = Modifier
                                                    .weight(1.8f)
                                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                                singleLine = true
                                            )

                                            // Percentage edit field
                                            Row(
                                                modifier = Modifier
                                                    .width(62.dp)
                                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                Text("%", fontSize = 10.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                                                BasicTextField(
                                                    value = k.yuzdeInput,
                                                    onValueChange = {
                                                        k.yuzdeInput = it
                                                        saveTrigger++
                                                    },
                                                    textStyle = TextStyle(
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = primaryGreen
                                                    ),
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                                    singleLine = true,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }

                                            // Calculated amount preview
                                            Text(
                                                text = "$mValue ₺",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textPrimary,
                                                modifier = Modifier.weight(0.9f),
                                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                                            )

                                            // Direct delete button
                                            IconButton(
                                                onClick = {
                                                    kesintiler.remove(k)
                                                    saveTrigger++
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Gideri Sil",
                                                    tint = Color(0xFFD32F2F).copy(alpha = 0.8f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 4.dp),
                                color = borderMuted
                            )
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Dağıtılacak Kalan:",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = primaryGreen
                                    )
                                )
                                Text(
                                    "$dailyKalan ₺",
                                    style = TextStyle(
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = primaryGreen
                                    )
                                )
                            }
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Çalışan Katsayısı Toplamı:", fontSize = 11.sp, color = textSecondary)
                                Text(String.format("%.2f Puan", dailyTotalPoints), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                            }
                        }
                    }

                    // Headers with batch options as requested: "Tum isimlerin calisip calismadigi da girilebilsin"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "PERSONEL KATILIMI & PAY",
                            style = TextStyle(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = textSecondary,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            "${activeDayStaff.size} / ${personeller.size} Çalışıyor",
                            style = TextStyle(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = primaryGreen
                            )
                        )
                    }

                    // Bulk actions for attendance entry convenience
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                personeller.forEach { p ->
                                    gun.calisanlar[p.id] = true
                                }
                                saveTrigger++
                            },
                            border = BorderStroke(1.dp, borderMuted),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = primaryGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Group, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Herkes Çalıştı", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                personeller.forEach { p ->
                                    gun.calisanlar[p.id] = false
                                }
                                saveTrigger++
                            },
                            border = BorderStroke(1.dp, Color(0xFFC62828).copy(alpha = 0.3f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Herkes İzinli", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Daily List of Personnel
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (personeller.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "Personel listesi boş.\nYeni personel eklemek için sağ alttaki '+' düğmesini kullanın.",
                                    color = textSecondary,
                                    fontSize = 13.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        } else {
                            personeller.toList().forEach { personel ->
                                val calisti = gun.calisanlar[personel.id] ?: true
                                val dynamicDailyPay = if (calisti && dailyTotalPoints > 0) {
                                    ((dailyKalan / dailyTotalPoints) * personel.puan).safeRoundToInt()
                                } else {
                                    0
                                }

                                PersonelRowCard(
                                    personel = personel,
                                    calisti = calisti,
                                    dynamicDailyPay = dynamicDailyPay,
                                    borderLight = borderLight,
                                    borderMuted = borderMuted,
                                    primaryGreen = primaryGreen,
                                    textPrimary = textPrimary,
                                    textSecondary = textSecondary,
                                    onActiveChange = { active ->
                                        gun.calisanlar[personel.id] = active
                                        saveTrigger++
                                    },
                                    onDelete = {
                                        personeller.remove(personel)
                                        saveTrigger++
                                    },
                                    onGlobalSaveTrigger = {
                                        saveTrigger++
                                    }
                                )
                            }
                        }
                    }
                } else if (currentTab == 7) {
                    // Weekly Summary Tab calculations
                    val totalWeeklyNakit = gunVerileri.sumOf { it.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0 }
                    val totalWeeklyKartGross = gunVerileri.sumOf { it.kart.replace(',', '.').toDoubleOrNull() ?: 0.0 }
                    val totalWeeklyKartNet = totalWeeklyKartGross * 0.88
                    val totalWeeklyCiro = totalWeeklyNakit + totalWeeklyKartNet

                    val totalWeeklyKalan = gunVerileri.sumOf { gun ->
                        val top = (gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0) + (gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0) * 0.88
                        val kesintiSum = kesintiler.sumOf { k ->
                            (top * (k.yuzde / 100.0)).safeRoundToInt()
                        }
                        top.safeRoundToInt() - kesintiSum
                    }

                    // Header with aggregate info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = "Haftalık Kümülatif Rapor",
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Financial Metrics Card (Aggregated frosted glass styling)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OzetSatir("Haftalık Brüt Nakit:", "${totalWeeklyNakit.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            OzetSatir("Haftalık Brüt Kart:", "${totalWeeklyKartGross.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            OzetSatir("Haftalık Kart Net (%12 Kesilmiş):", "${totalWeeklyKartNet.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            
                            kesintiler.forEach { k ->
                                val totalWeeklyKesintiValue = gunVerileri.sumOf { gun ->
                                    val top = (gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0) + (gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0) * 0.88
                                    (top * (k.yuzde / 100.0)).safeRoundToInt()
                                }
                                OzetSatir("Haftalık ${k.adi} Payı (%${k.yuzdeInput}):", "$totalWeeklyKesintiValue ₺", textSecondary, textPrimary)
                            }
                            
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 4.dp),
                                color = borderMuted
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Net Dağıtılacak Toplam:",
                                    style = TextStyle(
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryGreen
                                    )
                                )
                                Text(
                                    "$totalWeeklyKalan ₺",
                                    style = TextStyle(
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Black,
                                        color = primaryGreen
                                    )
                                )
                            }
                        }
                    }

                    // Consolidated Personnel Shares List Title
                    Text(
                        text = "HAFTALIK HAK EDİŞ LİSTESİ",
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = textSecondary,
                            letterSpacing = 0.5.sp
                        ),
                        modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 8.dp)
                    )

                    // Weekly Hak Ediş Card Grid List
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (personeller.isEmpty()) {
                            Text(
                                "Henüz kayıtlı personel yok.",
                                color = textSecondary,
                                modifier = Modifier.padding(12.dp)
                            )
                        } else {
                            personeller.forEach { personel ->
                                // Compute total accumulated share for this employee across all 7 days
                                val weeklyAccumulatedPay = gunVerileri.sumOf { gun ->
                                    val dailyN = gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0
                                    val dailyK = (gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0) * 0.88
                                    val dailyTot = dailyN + dailyK
                                    
                                    val kesintiSum = kesintiler.sumOf { k ->
                                        (dailyTot * (k.yuzde / 100.0)).safeRoundToInt()
                                    }
                                    val k = dailyTot.safeRoundToInt() - kesintiSum
                                    
                                    val activeStaff = personeller.filter { p -> gun.calisanlar[p.id] ?: true }
                                    val actPoints = activeStaff.sumOf { it.puan }
                                    
                                    val calismeDurum = gun.calisanlar[personel.id] ?: true
                                    if (calismeDurum && actPoints > 0) {
                                        ((k / actPoints) * personel.puan).safeRoundToInt()
                                    } else {
                                        0
                                    }
                                }

                                // Count active days
                                val activeDaysWorked = gunVerileri.count { gun ->
                                    gun.calisanlar[personel.id] ?: true
                                }

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = BorderStroke(1.dp, borderLight)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.Person, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(16.dp))
                                                Text(
                                                    text = personel.ad,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 15.sp,
                                                    color = textPrimary
                                                )
                                            }

                                            // Subtitle indicating active parameters and attendance statistics
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "${activeDaysWorked} / 7 Gün Çalıştı",
                                                    fontSize = 11.sp,
                                                    color = primaryGreen,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "Katsayı: ${personel.puanInput}",
                                                    fontSize = 11.sp,
                                                    color = textSecondary
                                                )
                                            }

                                            // Compact mini attendance badges for visual clarity
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.padding(top = 4.dp)
                                            ) {
                                                listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz").forEachIndexed { dIdx, dName ->
                                                    val worked = gunVerileri[dIdx].calisanlar[personel.id] ?: true
                                                    Box(
                                                        modifier = Modifier
                                                            .background(
                                                                color = if (worked) primaryGreen.copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f),
                                                                shape = RoundedCornerShape(4.dp)
                                                            )
                                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = dName,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (worked) primaryGreen else Color.Gray
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // Grand Total consolidated share label
                                        Column(
                                            horizontalAlignment = Alignment.End,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = "$weeklyAccumulatedPay ₺",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 18.sp,
                                                color = if (weeklyAccumulatedPay > 0) primaryGreen else textSecondary
                                            )
                                            Text(
                                                text = "Haftalık Hak",
                                                fontSize = 10.sp,
                                                color = textSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (currentTab == 8) {
                    // Kesinti Ayarları Tab
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = "Kesinti Payı Tanımları",
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Nakit ve kart toplam net cironuz dağıtılmadan önce yapılacak kesinti/gider payları oranlarını buradan tanımlayabilirsiniz. Sırasıyla tüm günler için hesaplanır, cirodan düşülür ve kalan tutar çalışanlara paylaştırılır.",
                            fontSize = 12.sp,
                            color = textSecondary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (kesintiler.isEmpty()) {
                            Text(
                                "Kayıtlı kesinti bulunmuyor. Yeni bir tane eklemek için sağ alttaki '+' tuşunu kullanın.",
                                color = textSecondary,
                                modifier = Modifier.padding(12.dp)
                            )
                        } else {
                            kesintiler.toList().forEach { kesinti ->
                                KesintiRowCard(
                                    kesinti = kesinti,
                                    borderLight = borderLight,
                                    borderMuted = borderMuted,
                                    primaryGreen = primaryGreen,
                                    textPrimary = textPrimary,
                                    textSecondary = textSecondary,
                                    onDelete = {
                                        kesintiler.remove(kesinti)
                                        saveTrigger++
                                    },
                                    onGlobalSaveTrigger = {
                                        saveTrigger++
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action confirmation dialog to safely wipe the sheet for a new business period
        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { showResetDialog = false },
                icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, tint = Color(0xFFC62828)) },
                title = { Text("Verileri Sıfırla?", fontWeight = FontWeight.Bold) },
                text = {
                    Text("Tüm günlerin nakit ve kart girişleri ile katılım verilerini tamamen sıfırlamak istediğinize emin misiniz? Bu işlem geri alınamaz.")
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                        onClick = {
                            gunVerileri.forEach { gun ->
                                gun.nakit = ""
                                gun.kart = ""
                                // Clean up day indicators
                                gun.calisanlar.clear()
                            }
                            saveTrigger++
                            showResetDialog = false
                        }
                    ) {
                        Text("Sıfırla", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showResetDialog = false }) {
                        Text("İptal", fontWeight = FontWeight.SemiBold, color = textSecondary)
                    }
                }
            )
        }

        // Highly polished Floating Add Personnel or Kesinti dialog
        if (showDialog) {
            if (currentTab == 8) {
                var yeniAdi by remember { mutableStateOf("") }
                var yeniYuzde by remember { mutableStateOf("5.0") }

                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Percent, contentDescription = null, tint = primaryGreen)
                            Text("Yeni Kesinti Ekle", fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = yeniAdi,
                                onValueChange = { yeniAdi = it },
                                label = { Text("Kesinti Adı") },
                                placeholder = { Text("Örn: Mutfak") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = yeniYuzde, 
                                onValueChange = { yeniYuzde = it }, 
                                label = { Text("Yüzde Oranı (%)") },
                                placeholder = { Text("Örn: 15.0") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                            shape = RoundedCornerShape(8.dp),
                            onClick = {
                                if (yeniAdi.isNotBlank()) {
                                    val valYuzde = yeniYuzde.replace(',', '.').toDoubleOrNull() ?: 5.0
                                    val k = KesintiKategori(java.util.UUID.randomUUID().toString(), yeniAdi.trim(), valYuzde).apply {
                                        yuzdeInput = yeniYuzde
                                    }
                                    kesintiler.add(k)
                                    saveTrigger++
                                    showDialog = false
                                }
                            }
                        ) {
                            Text("Ekle", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(
                            colors = ButtonDefaults.textButtonColors(contentColor = textSecondary),
                            onClick = { showDialog = false }
                        ) {
                            Text("İptal", fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
            } else {
                var yeniAd by remember { mutableStateOf("") }
                var yeniPuan by remember { mutableStateOf("1.0") }

                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = primaryGreen)
                            Text("Mürettebata Ekle", fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = yeniAd,
                                onValueChange = { yeniAd = it },
                                label = { Text("Personel Adı") },
                                placeholder = { Text("Örn: Cem") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = yeniPuan, 
                                onValueChange = { yeniPuan = it }, 
                                label = { Text("Hak Puanı (Katsayı)") },
                                placeholder = { Text("Örn: 1.0") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                            shape = RoundedCornerShape(8.dp),
                            onClick = {
                                if (yeniAd.isNotBlank()) {
                                    val valPuan = yeniPuan.replace(',', '.').toDoubleOrNull() ?: 1.0
                                    val p = Personel(java.util.UUID.randomUUID().toString(), yeniAd.trim(), valPuan).apply {
                                        puanInput = yeniPuan
                                    }
                                    personeller.add(p)
                                    // Enable them on all days by default
                                    gunVerileri.forEach { gun ->
                                        gun.calisanlar[p.id] = true
                                    }
                                    saveTrigger++
                                    showDialog = false
                                }
                            }
                        ) {
                            Text("Ekle", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(
                            colors = ButtonDefaults.textButtonColors(contentColor = textSecondary),
                            onClick = { showDialog = false }
                        ) {
                            Text("İptal", fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun OzetSatir(
    etiket: String, 
    deger: String, 
    labelColor: Color, 
    valueColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(etiket, fontSize = 13.sp, color = labelColor)
        Text(deger, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
fun CustomEditField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    singleLine: Boolean = true,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    placeholder: String = ""
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        textStyle = textStyle,
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        decorationBox = { innerTextField ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty() && placeholder.isNotEmpty()) {
                    Text(
                        text = placeholder,
                        color = Color.Gray.copy(alpha = 0.4f),
                        style = textStyle
                    )
                }
                innerTextField()
            }
        }
    )
}

@Composable
fun PersonelRowCard(
    personel: Personel,
    calisti: Boolean,
    dynamicDailyPay: Int,
    borderLight: Color,
    borderMuted: Color,
    primaryGreen: Color,
    textPrimary: Color,
    textSecondary: Color,
    onActiveChange: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onGlobalSaveTrigger: () -> Unit
) {
    val cardBorder = if (calisti) {
        BorderStroke(1.dp, borderLight)
    } else {
        BorderStroke(1.dp, borderMuted)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (calisti) 1f else 0.55f),
        shape = RoundedCornerShape(12.dp),
        border = cardBorder,
        colors = CardDefaults.cardColors(
            containerColor = if (calisti) Color.White else Color.White.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Personel Adı", fontSize = 11.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    CustomEditField(
                        value = personel.ad,
                        onValueChange = { 
                            personel.ad = it 
                            onGlobalSaveTrigger()
                        },
                        textStyle = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        ),
                        placeholder = "Personel Adı",
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column {
                            Text("Hak Katsayısı", fontSize = 11.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            CustomEditField(
                                value = personel.puanInput,
                                onValueChange = { 
                                    personel.puanInput = it
                                    onGlobalSaveTrigger()
                                },
                                textStyle = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (calisti) primaryGreen else textSecondary
                                ),
                                placeholder = "1.0",
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.width(90.dp)
                            )
                        }
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = "$dynamicDailyPay ₺",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = if (calisti && dynamicDailyPay > 0) primaryGreen else textSecondary
                    )
                    Text(
                        text = "Günlük Pay",
                        fontSize = 9.sp,
                        color = textSecondary
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFFFFEBEE), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Dünyadan Kaldır",
                        tint = Color(0xFFD32F2F),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF1F8E9))
                    .border(1.dp, borderMuted, RoundedCornerShape(8.dp))
                    .padding(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (calisti) primaryGreen else Color.Transparent)
                        .clickable { onActiveChange(true) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (calisti) Color.White else textSecondary
                        )
                        Text(
                            text = "Çalıştı",
                            color = if (calisti) Color.White else textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (!calisti) Color(0xFFD32F2F) else Color.Transparent)
                        .clickable { onActiveChange(false) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (!calisti) Color.White else textSecondary
                        )
                        Text(
                            text = "Çalışmadı (İzinli)",
                            color = if (!calisti) Color.White else textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KesintiRowCard(
    kesinti: KesintiKategori,
    borderLight: Color,
    borderMuted: Color,
    primaryGreen: Color,
    textPrimary: Color,
    textSecondary: Color,
    onDelete: () -> Unit,
    onGlobalSaveTrigger: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, borderLight),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Kesinti/Gider Adı",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryGreen
                )
                
                CustomEditField(
                    value = kesinti.adi,
                    onValueChange = { 
                        kesinti.adi = it 
                        onGlobalSaveTrigger()
                    },
                    textStyle = TextStyle(
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    ),
                    placeholder = "Örn: Mutfak",
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Yüzde Oranı (%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryGreen
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        CustomEditField(
                            value = kesinti.yuzdeInput,
                            onValueChange = { 
                                kesinti.yuzdeInput = it
                                onGlobalSaveTrigger()
                            },
                            textStyle = TextStyle(
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            ),
                            placeholder = "Örn: 15.0",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFFFFEBEE), RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Kesintiyi Sil",
                    tint = Color(0xFFD32F2F),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}


